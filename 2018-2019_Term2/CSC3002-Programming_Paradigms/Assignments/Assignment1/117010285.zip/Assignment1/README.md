## CSC3002 Assignment 1

The source code is a submission for CSC3002 Introduction to Computer Science II, Assignment 1.

### Author Information

Student Name: WU, Chenhao (Vito)

Student ID: 117010285

### Building

#### Linux (with GCC 8.2 in minimum)

Building of this project need to pre-install CMake


```
sudo apt install cmake
cd $SRC_Dir
mkdir build
cd build
cmake ..
make 
```

### Run

```
cd $SRC_Dir/build
./Assignment1/ASSIGNMENT1_MAIN
```
